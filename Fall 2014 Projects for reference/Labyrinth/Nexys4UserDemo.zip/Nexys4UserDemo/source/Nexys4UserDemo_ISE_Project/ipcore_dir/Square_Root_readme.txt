The following files were generated for 'Square_Root' in directory
D:\Digilent\Projects\Nexys4\Nexys4UserDemo\source\Nexys4UserDemo_ISE_Project\ipcore_dir\

Generate XCO file:
   CORE Generator input file containing the parameters used to generate a core.

   * Square_Root.xco

Generate Implementation Netlist:
   Binary Xilinx implementation netlist files containing the information
   required to implement the module in a Xilinx (R) FPGA.

   * Square_Root.ngc

Obfuscate Netlist Generator:
   Please see the core data sheet.

   * Square_Root.ngc

Generate Instantiation Templates:
   Template files containing code that can be used as a model for instantiating
   a CORE Generator module in an HDL design.

   * Square_Root.vho

RTL Simulation Model Generator:
   Please see the core data sheet.

   * Square_Root.vhd

All Documents Generator:
   Please see the core data sheet.

   * Square_Root/doc/cordic_ds249.pdf
   * Square_Root/doc/cordic_v4_0_vinfo.html

Deliver IP Symbol:
   Graphical symbol information file. Used by the ISE tools and some third party
   tools to create a symbol representing the core.

   * Square_Root.asy

SYM file generator:
   Generate a SYM file for compatibility with legacy flows

   * Square_Root.sym

Generate XMDF file:
   ISE Project Navigator interface file. ISE uses this file to determine how the
   files output by CORE Generator for the core can be integrated into your ISE
   project.

   * Square_Root_xmdf.tcl

Generate ISE project file:
   ISE Project Navigator support files. These are generated files and should not
   be edited directly.

   * Square_Root.gise
   * Square_Root.xise
   * _xmsgs/pn_parser.xmsgs

Deliver Readme:
   Readme file for the IP.

   * Square_Root_readme.txt

Generate FLIST file:
   Text file listing all of the output files produced when a customized core was
   generated in the CORE Generator.

   * Square_Root_flist.txt

Please see the Xilinx CORE Generator online help for further details on
generated files and how to use them.

